<?php
// Keep your Stripe API key protected by including it as an environment variable
// or in a private script that does not publicly expose the source code.

// This is your test secret API key.
$stripeSecretKey = 'sk_test_51Kx533JsQd5pkfLs1rLUtm5dBJZUrtWer96ko13bbNTY6XFIolsYaXiSobmNswj9pamBo2AR0V301786y7sux8Pp007wZY4P9J';